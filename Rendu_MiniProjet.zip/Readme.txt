Rendu :
-Jar executable "MiniProjet.jar"
-Code source du programme dans le dossier src
-Rapport de projet au format PDF
-Ce Readme

Execution : 
-extraire le .jar et l'executer classiquement.
-Rien a installer.