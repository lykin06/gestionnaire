package materiel;

/**
 * @author M.Boutelier
 */
public class Materiel {
	private int dureeMax;
	
	public Materiel(int dureeMax) {
		this.dureeMax = dureeMax;
	}
	
	public int getDureeMax() {
		return dureeMax;
	}
	
}
