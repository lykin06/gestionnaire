package users;


public class Etudiant extends Emprunteur {
	
	public Etudiant(String name) {
		super(Type.ETUDIANT, name);
	}
}
