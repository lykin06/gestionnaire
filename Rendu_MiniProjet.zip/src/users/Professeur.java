package users;

/**
 * @author M.Boutelier
 */
public class Professeur extends Emprunteur {
	
	public Professeur(String name) {
		super(Type.PROFESSEUR, name);
	}

}
