package src;

import java.util.*;

/**
*Cette classe permet de gerer le stock de materiel disponible de l'atelier.
*
*@author Khady FALL et Youssef SALIM
*@version 3.0 (26/11/13)
*/

public class Stock implements java.io.Serializable{
/**
*La liste du materiel total, c'est a dire ceux qui sont disponibles et ceux qui sont empruntes
*On pourrait faire des mises à jour dans cette liste,en ajoutant ou en retirant des elements
*@see Stock#ajouterUnType(String )
*@see Stock#ajouterUnNombre(String ,int)
*@see Stock#retirer(String,int)
*/

private ArrayList<TypeDeMateriel>  listeTypeDeMateriel;

/**
*Construit un stock avec une liste en parametre 
*
*/

public Stock(ArrayList<TypeDeMateriel> liste)
{
	listeTypeDeMateriel=liste;
}
/**
*Construit un stock vide
*
*/
public Stock()
{
	this(new ArrayList<TypeDeMateriel>());
}
/**
*Retourne la liste de type de materiels
*@return une liste de typeDeMateriel 
*
*/

public ArrayList<TypeDeMateriel> getListeTypeDeMateriel(){
	return listeTypeDeMateriel;
}

/**
*Renvoie l'indice du type entre en parametre dans le stock, indice incoherent sinon
*@param type
*			le type dont l'indice est cherche
*@return l'indice de ce type s'il est contenu, sinon indice incoherent
*
*/
public int getType(String type){
int i = 0;
	boolean trouve = false;
	while(i < listeTypeDeMateriel.size() && !trouve){
		trouve = listeTypeDeMateriel.get(i).getType().equals(type);
		i++;
	}

	if(trouve){ return i-1;}
	else{ return -1;}
}
/**
*Ajout d'un type de materiel,s'il est nouveau ,il est ajouté en fin de liste ,sinon on rajoute son nombre d'exemplaire au stock
*@param type le type de materiel à ajouter
*@see Stock#ajouterUnType(String,int)
*/

public boolean ajouterUnType(String type){
	boolean probleme;
	if(getType(type)==-1){
		listeTypeDeMateriel.add(new TypeDeMateriel(type,0)); probleme = false;
	}
	else{probleme = true;}
	return probleme;
}

/**
*Verifie l'ajout d'un nouveau TypeDeMateriel de type "type" et de n nombre de materiels de ce type
*@param type  le type de materiel a ajouter
*@param nombreExemplaire le nombre d'exemplaire a ajouter
*@return vrai si c'est bien ajouter, faux sinon 
*@see Stock#ajouterUnNombre(String ,int)
*
*/
public boolean ajouterUnType(String type, int n){
	boolean reussi;
	if(getType(type)==-1){
		listeTypeDeMateriel.add(new TypeDeMateriel(type,n)); reussi = true;
	}
	else{reussi = false;}
	return reussi;
}
/**
*Ajout d'un nombre d'exemplaires supplementaires de type "type"
*@param type  le type de materiel à ajouter
*@param nombreExemplaire le nombre d'exemplaire à ajouter
*@return vrai si c'est bien ajouter, faux sinon 
*@see Stock#ajouterUnType(String)
*@see TypeDeMateriel#typeDeMateriel(String ,int)
*/


public boolean ajouterUnNombre(String type, int nbreExemplaire){
	int i;
	boolean reussi;

	i = getType(type);
	if(i==-1){reussi = false;}
	else{listeTypeDeMateriel.get(i).ajouterMateriel(nbreExemplaire); reussi = true;}
	
	return reussi;
}

/**
*Renvoie le type de materiel en plus grand nombre d'exemplaire
*@return un type de materiel le plus courant dans le stock 
*@see TypeDeMateriel
*/
public TypeDeMateriel typeDeMaterielEnPlusGrandNombre()
{int maxMat=0;
for(int i=1;i<listeTypeDeMateriel.size();i++)
if(listeTypeDeMateriel.get(i).nombreDeMateriel()>listeTypeDeMateriel.get(maxMat).nombreDeMateriel())
{maxMat=i;
}
return listeTypeDeMateriel.get(maxMat);
}

/**
*Qui renvoie le nombre d'exemplaires en stock d'un type  donné 
*@param type
*			le type du materiel dont on veut connaitre le nombre
*@return le nombre d'exemplaires du type
*/
public int exemplairesEnStock(String type)
{
for(int i=0; i<listeTypeDeMateriel.size();i++)
{if(listeTypeDeMateriel.get(i).getType().equals(type))
return listeTypeDeMateriel.get(i).nombreDeMateriel();
}
 return 0;
}

/**
*Compte le nombre de telephones dans le stock
*@return le nombre apres comptage
*@see Stock#exemplairesEnStock
*/
public int nombreDeTel(){
int compteur=0;
for(int i=0;i<listeTypeDeMateriel.size();i++)
if(listeTypeDeMateriel.get(i).getIdentification().equals("TEL"))
{compteur++;
}
return compteur;
}
/**
* renvoie le nombre total de materiels en stock,peu importe le type
*@return le resultat final du compteur de materiels
*/
public int nombretotalDeMaterielsEnStock(){
	int compteur=0;
	for(int i=0;i<listeTypeDeMateriel.size();i++)
		{compteur+=listeTypeDeMateriel.get(i).nombreDeMateriel();
		}
return compteur;
}

/**
*Renvoie le type correspondant a un identifiant de materiel donne s'il existe ,sino renvoie inconnu
*Utile pour identidier un materiel
*@param id l'identifiant du materiel
*@return un type TypeDeMateriel : le type de materiel de cet identifiant
*/
public TypeDeMateriel getTypeId(String id){
	if(id.length()==8){
		for(int i=0; i < listeTypeDeMateriel.size(); i++){
			if(listeTypeDeMateriel.get(i).getIdentification().equals(id.substring(0,6))){ return listeTypeDeMateriel.get(i);}
		}
	}
	return new TypeDeMateriel("inconnu",0);
}

/**
*Renvoie le materiel du stock d'identifiant donne s'il existe , un element non pertinent sinon
*@param id
*			l'identifiant
*@return le materiel
*/
public Materiel getMat(String id){
	TypeDeMateriel type = getTypeId(id);

	//dans typeDeMat, on trouve le mat
	if(id.length()==8){
		for(int j=0; j<type.nombreDeMateriel();j++){
			if(id.equals(type.getMateriel(j).getId())){
			return type.getMateriel(j);
			}
		}
	}

	return new Materiel("inconnu","");
}
/**
*Renseigne les informations des differents types de materiels contenant des materiels disponibles 
*
*/
public String toString(){
	return ""+listeTypeDeMateriel;
}

}

