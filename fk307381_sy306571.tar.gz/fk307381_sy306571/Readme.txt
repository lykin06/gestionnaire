
 PROGRAMME DE GESTION DES MATERIELS DE L'ATELIER 

***********************************Installation******************************************
Cette version nécessite l'installation de Java version 1.6.0 sur votre PC. Celle-ci est gratuite et disponible sur 
http://www.java.com/fr/download/manual.jsp
Pour installer FALL_SALIM :
- après avoir installé le programme Java, créez un répertoire de nom de votre choix sur votre PC pour recevoir le programme
- dans ce répertoire : dézippez l'archive FALL_SALIM à l'aide d'un clic droit suivi du clic "extraire ici"
- en fonction de votre environnement (windows/linux), lancez le programme FALL_SALIM.



***************************Fonctionnalités du programme*************************************

Le programme est destiné à la gestion d'un stock de matériels informatiques mis à la disposition des étudiants d'une école, gestion, plus précisément, de l'acquisition, la réparation, l'emprunt et le retour de ces matériels.
Le respect des modalités d'emprunt par l'emprunteur est supposée toujours vérifiée.



***************************Comment utiliser ce programme?***********************************
-Editez un terminal selon que vous sous Linux (Ctrl+Alt+t) ou sur Windows (demarrer --> executer)
-Accedez directement à votre repertoireen vous y placant pour compiler par cd ~/nom_de_mon_repertoire/fk307381_sy306571/src
-Compilez les fichiers source dans cet ordre : 
	-->Materiel
	--->TypeDeMateriel et Emprunteur (dans un ordre quelconque)
	---->Stock
	------>Atelier
	-------->Menu
avec la commande javac nom_du_fichier.java
-Apres l'exécution du programme avec java Menu.java, se laisser guider par les instructions affichées à l'écran.
-tapez choisir l'une des options proposées en tapant un des chiffres 



************************Comment se documenter sur ce programme?*************************************
-Tapez dans le terminal cd ~/FALL_SALIM/doc
-faire un double clic sur la classe sur laquelle vous souhaitez vous documenter


************************Comment nous contacter pour d'eventuelles suggestions?*************************************
Contact:
	-->fall.khady@etu.unice.fr
	---->youssef.salim@etu.unice.fr



