package src;
import java.util.*;

/**
*Cette classe permet de gerer l'ensemble du stock de materiels c'est à dire ceux disponibles,ceux empruntés 
* les informations sur les emprunteurs et  les informations sur le materiel en reparation et sur le materiel emprunté.
*
*@author Khady FALL et Youssef SALIM
*@version 3.0 (26/11/13)
*/
public class Atelier implements java.io.Serializable{
private Stock  stock;
private ArrayList<Emprunteur> listeEmprunteur;
private ArrayList<Materiel> listeReparation;


/**
*Permet de construire un Atelier avec des caracteristiques donnés.
*@param stock: le materiel disponible
*@param emprunteurs :la liste d'emprunteurs avec les differentes informations sur les emprunteurs
*@param reparation: la liste de materiels enl reparation
*/

public Atelier(Stock stock,ArrayList<Emprunteur> emprunteurs, ArrayList<Materiel> reparation)
{
	this.stock=stock;
	listeEmprunteur = emprunteurs;
	listeReparation=reparation;
}

/**
*Construit un nouvel Atelier c'est à dire ne contenant encore aucun materiels.
*Cette methode est particulierement utile pour le demarrage de l'atelier.
*
*/

public Atelier(){
	this(new Stock(),new ArrayList<Emprunteur>(),new ArrayList<Materiel>());
}


/**
*Renvoie les informations sur les differents emprunt qui ont été effectués
*@return listeEmprunteur: la liste des informations sur les emprunts 
*
*/

public ArrayList<Emprunteur> getListeEmprunteur(){
	return listeEmprunteur;
}
/**
*Renvoie les informations sur le stock courant
*@return stock: le stock de l'atelier
*
*/
public Stock getStock(){
	return stock;
}
/**
*Renvoie les informations sur le materiel en reparation
*@return listeReparation la liste de  materiels en reparation
*
*/
public ArrayList<Materiel> getListeReparation(){
	return listeReparation;
}
/**
*Retourne un TypeDeMateriel a reparer
*@param i
*		l'indice de l' objet type de  materiel
*@return un objet de TypeDeMateriel à reparer
*@see Materiel
*/
public Materiel getAReparer(int i){if (i<listeReparation.size())
	return listeReparation.get(i);
else return new Materiel();}

/**
*Modifie le stock courant
*@param monStock un nouveau Stock
*
*/
public void setStock(Stock monStock){
	stock = monStock;
}


//-----------------------1ere partie : gestion du materiel a reparer--------------------------------
/**
*Envoie un materiel a reparer dans la liste de reparation
*Utile pour l'elaboration de statistiques, c'est à dire connaitre le materiel qui s'use le plus rapidement
*@param id le numero d'identification du materiel
*@return true si le materiel est effectivement envoyé en reparation,false sinon
*@see Atelier#typeDeMaterielPlusRepare()
*/
public boolean reparerMateriel(String id){
	Materiel mat = stock.getMat(id);
	if(mat.getType().equals("inconnu"))return false;
	     else{listeReparation.add(mat); stock.getTypeId(id).supprimerMateriel(mat);
		return true;}
}
/**
*Permet de restituer un materiel qui avait été en reparation
*@param id l'indentifiant du materiel
*@return vrai si le materiel est rajouté au stock ,faux sinon
*/

public boolean restituerMat(String id){
	int i =0;
	boolean trouve = false;
	if(id.length()==9){
		while(i<listeReparation.size() && !trouve){
			if(!id.equals(listeReparation.get(i).getId())){
			i++;}
			else{trouve = true;}
		}

		if(trouve){ stock.getTypeId(id).ajouterMateriel(listeReparation.get(i)); 
			    listeReparation.remove(i); return true;}
		else{ return false;}
	}
	else{ return false;}
}
/**
*Renseigne le type de materiel le plus emprunte 
*@return le nom du type de materiel le plus emprunte
*
*/
public String typeDeMaterielPlusRepare(){
	ArrayList<String> listeType = new ArrayList<String>();
	ArrayList<Integer> listeExemplaires = new ArrayList<Integer>();
	String type;
	int j;
	for(int i = 0; i<listeReparation.size();i++){
		type = listeReparation.get(i).getType();
		j = listeType.indexOf(type);
		if(j==-1){
			listeType.add(type);
			listeExemplaires.add(1);
		}
		else{	
			listeExemplaires.set(j,listeExemplaires.get(j)+1); }
	}

	//A la recherche du max
	int max = 0;
	int indMax = 0;
	for(int k = 0; k < listeType.size();k++){
		if(max < listeExemplaires.get(k)){
			max = listeExemplaires.get(k);
			indMax = k;
		}
	}
	
	if(max==0){ return "Aucun materiel en reparation";}
	else{ return listeType.get(indMax);}
}

/**
*Renseigne le plus gros Emprunteur  de l'atelier 
*@return le nom du plus gros emprunteur de l'atelier 
*Particulierement utile pour connaitre le client le plus fidele
*@see Atelier#typeDeMaterielPlusEmprunte()
*/
public String plusGrosEmprunteur(){
	int max = 0;
	int longueur;
	Emprunteur emprunteur;
	String nom = "";
	for(int i=0;i<listeEmprunteur.size();i++){
		emprunteur = listeEmprunteur.get(i);
		longueur = emprunteur.getNombreEmprunte();
		if(max < longueur){
			max = longueur;
			nom = emprunteur.getNom();
		}
	}

	if(max==0){return "Aucun emprunt en cours";}
	else{ return nom;}
}

/**
*
*Permet de connaitre le type de materiel le plus emprunte
*Particulierement utile pour faire des statistiques
*@return le nom du materiel le plus emprunte
*@see Atelier#lePlusGrosEmprunteur()
*
*/

public String typeDeMaterielPlusEmprunte(){
	ArrayList<String> type = new ArrayList<String>();
	ArrayList<Integer> exemplaires = new ArrayList<Integer>();
	Materiel mat;	
	int j;

	for(int i=0;i<listeEmprunteur.size();i++){
		mat = listeEmprunteur.get(i).getMaterielEmprunte(i);
		j = type.indexOf(mat.getType());
		if(j==-1){
			 type.add(mat.getType()); exemplaires.add(1);
		}
		else{ exemplaires.set(j,exemplaires.get(j)+1);}
	}

	//A la recherche du max...
	int max = 0;
	String nom = "";
	for(int i=0;i<type.size();i++){
		if(max < exemplaires.get(i)){
			max = exemplaires.get(i);
			nom = type.get(i);
		}
	}

	if(max==0){return "Aucun emprunt en cours";}
	else{ return nom;}
}

//------------------2eme partie :  gestion des emprunts et des retours---------------------------------


/**
*Permet de preter un materiel disponible a un client donne
*Precondition:
*				-ce client ne se trouve pas dans la liste des emprunteurs
*				-les dates d'emprunt et de retour doivent etre constitué de 6chiffres
*@param nom: le nom  du client qui desire emprunter
*@param prenom: son prenom
*@param type: le type de materiel qu'il desire emprunter
*@param dateEmprunt: la date de l'emprunt
*@param dateRetour: la date de retour
*@param nombre : la nombre de materiels de ce type qu'il desire emprunter
*@see Atelier#retourner(String)
*/
public boolean emprunter(String nom,String prenom, TypeDeMateriel type, String dateEmprunt, String dateRetour,int nombre){
	if(!type.materielNonEmprunte().isEmpty()&& nombre<type.materielNonEmprunte().size())
		{ArrayList<Materiel> liste=new ArrayList<Materiel>();
			for(int i=0; i<nombre;i++)

				{type.materielNonEmprunte().get(i).switchEtat();
					type.materielNonEmprunte().get(i).setDateEmprunt(dateEmprunt);
					type.materielNonEmprunte().get(i).setDateRetour(dateRetour);
					liste.add(type.materielNonEmprunte().get(i));
				}
					ajoutEmprunteur(new Emprunteur(nom,prenom,liste));
				
			return true;}
			else return false;
	}
/**
*Emprunter un materiel
	*Pre-condition : le materiel avec cet identifiant existe et est disponible
	*@param emp l'emprunteur
	*@param mat le materiel qu'il desire emprunter
	*@param dateEmprunt la date d'emprunt
	*@param dateRetour la date de retour
	*/
public void emprunter(Emprunteur emp, Materiel mat, String dateEmprunt, String dateRetour){
	
	mat.switchEtat();
	mat.setDateEmprunt(dateEmprunt); mat.setDateRetour(dateRetour); 
	emp.ajouterMaterielEmprunte(mat);
}

/**
*Permet de retourner un materiel emprunte auparavant  dans le stock lors du rendu  d'un client
*@param  id l'identite de materiel
*/

public void retourner(String id){
	Materiel mat = stock.getMat(id);

	if(mat.getType().equals("inconnu")){System.out.println("Identifiant erroné");}
	else if(!mat.getEtat()){System.out.println("Matériel déjà disponible");}
	     else{mat.switchEtat(); 
		  int i = 0;
		  int j;
		  boolean fin = false;
		  while(i < listeEmprunteur.size() && !fin){
			j = 0;
			while(j < listeEmprunteur.get(i).getListeDesEmpruntes().size()){
				if(mat==listeEmprunteur.get(i).getMaterielEmprunte(j)){
					fin = true;
					listeEmprunteur.get(i).supprimerMaterielEmprunte(j);
					//stock.ajouterUnNombre()
				}
				j++;
			}
			i++;
		  }
		  System.out.println("Matériel retourné");
		}
}

/**
*
*Ajout d'un nouvel emprunteur
*@param personne 
*				l'emprunteur
*@see emprunter(String ,String ,typeDeMateriel,String ,String ,int)
*
*/
public void ajoutEmprunteur(Emprunteur personne){listeEmprunteur.add(personne);}

/**
*Permet de  connaitre le nombre d'emprunteurs
*@return le nombre d'emprunteurs
*/
public int NombreEmprunteur(){return listeEmprunteur.size();}

/**
*Savoir si telle personne est bien dans la liste des emprunteurs
*@param nom
*			nom de la personne
*@return vrai s'il est emprunteur,faux sinon
*@see Stock#verificationEmprunteur(int i)
*/
public boolean verificationEmprunteur(String nom){Emprunteur emp=getEmprunteur(nom);return listeEmprunteur.contains(emp);}
/**
*Connaitre l'emprunteur qui se trouve a un index donne, si l'index n'est pas bon renvoi alors "inconnu"
*@param i
*		l'index
*@return l'emprunteur
*@see Stock#getEmprunteur(String)
*
*/
public Emprunteur  getEmprunteur(int i){ if(i<listeEmprunteur.size()) return listeEmprunteur.get(i); return new Emprunteur(); }
/**
*permet de savoir si le client est dans la liste des emprunteurs à partir de son nom
*@param nom
*			le nom de l'emprunteur
*@return l'emprunteur ou un inconnu
*@see Stock#getEmprunteur(String)
*
*/
public Emprunteur getEmprunteur(String nom){
	int i = 0;
	boolean trouve = false;
	while(i < listeEmprunteur.size() && !trouve){
		trouve = listeEmprunteur.get(i).getNom().equals(nom);
		i++;
	}

	if(trouve){ return listeEmprunteur.get(i-1);}
	else{ return new Emprunteur();}
}

	
/**
*permet de savoir le nombre de materiels empruntes d'un emprunteur 
*@param emprunteur
*		l'emprunteur
*@return le nombre de materiel emprunte 
*@see Stock#getNombreEmprunte(String )
*/
public int getNombreEmprunte(Emprunteur emprunteur){ int i=listeEmprunteur.indexOf(emprunteur); return listeEmprunteur.get(i).getNombreEmprunte();}
/**
*permet de savoir le nombre de materiels empruntes d'un emprunteur a partir de son nom
*@param nom
*		nom de l'emprunteur
*@return le nombre de materiel emprunte 
*@see Stock#getNombreEmprunte(Emprunteur )
*/
public int getNombreEmprunte(String nom){int i=getIndexEmprunteur(getEmprunteur(nom)); return listeEmprunteur.get(i).getNombreEmprunte();}
/**
*Retourne  l'index d'un emprunteur dans la liste des emprunteurs
*pre -condition: l'emprunteur est dans la liste des emprunts
*@param emprunteur
*			l'emprunteur
*@return l'index 
*@see Stock#getIndexEmprunteur(String )
*/
public int getIndexEmprunteur(Emprunteur emprunteur){return listeEmprunteur.indexOf(emprunteur);}
/**
*Retourne  l'index d'un emprunteur dans la liste des emprunteurs
*pre -condition: l'emprunteur est dans la liste des emprunts
*@param nom
*			le nom de l'emprunteur
*@return l'index 
*@see Stock#getIndexEmprunteur(String)
*/

public int getIndexEmprunteur(String nom){Emprunteur emp=getEmprunteur(nom);return listeEmprunteur.indexOf(emp);}
/** 
*Supprime un emprunteur de la liste des emprunts apres retour du materiel emprunte
*Pre-condition :l'emprunteur doit etre dans la liste des emprunts
* @param nom
*			le nom de l'emprunteur
*@return l'emprunteur  effectivement supprime
*/
public Emprunteur removeEmprunteur(String nom){ 
		{int i=getIndexEmprunteur(getEmprunteur(nom));return listeEmprunteur.remove(i);}
}


public String toString(){
	return "Materiels empruntables : "+stock.toString()+"\n\nMateriels empruntés: "+listeEmprunteur+"\n\nMateriel en reparation:   "+listeReparation;
}

}
