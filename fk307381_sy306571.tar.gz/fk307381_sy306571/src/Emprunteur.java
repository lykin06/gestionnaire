package src;
import java.util.*;
/**
*permet de gerer chaque emprunt  effectué grace aux  informations sur l'emprunteur et sur le materiel emprunté 
**@author Khady FALL et Youssef SALIM
*@version 3.0 (22/11/13)
*/

public class Emprunteur implements java.io.Serializable{
	/**
*le nom de l'emprunteur
*/
private String nom;
	/**
*le prenom de l'emprunteur
*/
private String prenom;
/**
*la liste du materiel emprunte
*@see ajouterMaterielEmprunte(Materiel)
*@see getMaterielEmprunte(int )
*@see supprimerMaterielEmprunte(Materiel)
*/
private ArrayList<Materiel> listeDesEmpruntes;

/**
*Permet de construire un nouvel emprunteur
*@param nom le nom de l'emprunteur 
*@param prenom le prenom de l'emprunteur 
*@param liste la liste de materiels empruntes venant d'etre validés
*/
public Emprunteur (String nom,String prenom,ArrayList<Materiel> liste)
{
	this.nom=nom;
	this.prenom=prenom;
	this.listeDesEmpruntes=liste;

}

public Emprunteur (String nom,String prenom)
{
	this.nom=nom;
	this.prenom=prenom;
	this.listeDesEmpruntes=new ArrayList<Materiel>();

}

/**
*Permet de renvoyer un emprunteur inconnu si celui ne se trouve pas dans la liste
*
*/

public Emprunteur (){
	this("inconnu","inconnu",null);
}

/**
*Renvoie le nom d'un emprunteur
*@return le nom de l'emprunteur
*/

public String getNom(){
	return nom;
}
/**
*Renvoie le prenom d'un emprunteur
*@return le prenom de l'emprunteur
*/

public String getPrenom(){
	return prenom;
}
/**
*Renvoie l'ensemble du materiels empruntés 
*@return le materiel emprunté
*/

public ArrayList<Materiel> getListeDesEmpruntes()
{
	return this.listeDesEmpruntes;
}
/**
*Renseigne le nombre de materiels empruntés pour un emprunteur donné
*@return le nombre de materiel emprunté
*/
public int getNombreEmprunte(){
 return listeDesEmpruntes.size();
}
/**
*Renvoie les informations sur un materiel  emprunté
*@return un type Materiel s'il est dans la liste du materiels empruntés
*@param i l'index du materiel dans la liste
*/
public Materiel getMaterielEmprunte(int i)
{		if(i<getNombreEmprunte())
	return listeDesEmpruntes.get(i);
	else return new Materiel();
}
/**
*Methode qui ajoute un materiel dasn la liste des emprunts
*@param mat le materiel devant étre ajouté
*/
public  void ajouterMaterielEmprunte(Materiel mat){
	listeDesEmpruntes.add(mat);
}
/**
*Methode qui supprime un materiel emprunte de la liste
*Methode utile pour les rendus
*@param mat le materiel a supprimer
*@see Emprunteur#supprimerMaterielEmprunte(int)
*/
public  void supprimerMaterielEmprunte(Materiel mat){
	listeDesEmpruntes.remove(mat);
}

/**
*Methode qui supprime un materiel emprunte de la liste
*Methode utile pour les rendus
*@param mat le materiel a supprimer
*@see Emprunteur#supprimerMaterielEmprunte(String )
*/
public void supprimerMaterielEmprunte(int i){
	listeDesEmpruntes.remove(i);
}
/**
*Renseigne l'ensemble des informations sur un emprunt donne
*Utile pour les consultations, les rendus et les mises à jour
*
*/
public String toString()
{  String tab="\n\t";
	if(!listeDesEmpruntes.isEmpty())

return "Emprunteur    : "+nom.toUpperCase()+" "+this.prenom+"\n\tMateriels empruntes"+listeDesEmpruntes;
else return "Emprunteur    : "+nom.toUpperCase()+"\nil n'a effectué aucun emprunt";

}

}
