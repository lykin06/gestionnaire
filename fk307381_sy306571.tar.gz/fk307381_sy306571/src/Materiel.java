
package src;
/**
*Permet de gerer chaque materiel de l'atelier particulierement pour les operations
* d' emprunt ,d'achat, de disponibilite ou de mise en reparation
**@author Khady FALL et Youssef SALIM
*@version 3.0 (22/11/13)
*/
public class Materiel implements java.io.Serializable{

/**
*le type du materiel
*/	
private String type;
/**
*la date d'emprunt du materiel s'il a ete emprunte de la forme JJMMAA
*Precondition: cette date doit etre au format de six chiffres JJMMAA
*/
private String dateEmprunt;
/**
*la date de retour du materiel s'il a ete emprunte de la forme JJMMAA
*Precondition: cette date doit etre au format de six chiffres JJMMAA
*/
private String dateRetour; 
/**
*l'etat du materirl c'est a dire s'il a ete emprunte ou pas
*/
private boolean etatEmp; 

private static int nombre = 100;
/**
*l'identifiant du materiel permettant de le distinguer des autres materiels de meme type
*/
private String id;


/**
*
*Construit un materiel emprunte d'dentifiant unique
*Pre condition:Disponile dans le stock
*@param type le type de materiel
*@param dateEmprunt  la date d'emprunt 
*@param dateDeRetour la date de retour du materiel
*@param  etatEmp  l'etat du materiel
*@param id l'identifiant
*/
public Materiel(String type, String dateEmprunt, String dateRetour, boolean etatEmp, String id){
	this.type = type;
	this.dateEmprunt = dateEmprunt;
	this.dateRetour = dateRetour;
	this.etatEmp = etatEmp;
	this.id = id;
}



/**
*Construit un materiel non emprunte
*@param type le type de materiel
*@param id l'indentifiant du materiel
*/
public Materiel(String type, String id){
	this(type,"000000","000000",false,id);
}
public Materiel(String type){
	this.type=type;
	this.dateEmprunt="0000";
	this.dateRetour="0000";
	this.etatEmp=false;
}
public Materiel (){
	this("inconnu","000000","000000",false,"inconnu");
}
/**
*Retourne le type du materiel
*@return le type 
*/
public String getType(){
	return type;
}
/**
*Retourne l'etat du materiel
*@return vrai si emprunte ,faux sinon
*/
public boolean getEtat(){
	return etatEmp;
}
/**
*Retourne la date d'emprunt d'un materiel donne
*Precondition: le materiel doit etre a l'etat emprunte
*@return la date d'emprunt
*/
public String getDateEmprunt(){
	return dateEmprunt;
}
/**
*Retourne la date de retour d'un materiel
*Pre condition: le materiel doit etre a l'etat emprunte
*@return la date de retour
*/
public String getDateRetour(){
	return dateRetour;
}
/**
*Retourne l'identifiant du materiel
*@return l'identifiant
*/
public String getId(){
	return id;
}
/**
*Change la date d'emprunt
*Precondition: la nouvelle  date doit etre au format de six chiffres JJMMAA 
*@param dateEmprunt la nouvelle date d'emprunt
*
*/
public void setDateEmprunt(String dateEmprunt){
	this.dateEmprunt = dateEmprunt;
}
/**
*Change la date de retour
*Precondition: la nouvelle date doit etre au format de six chiffres JJMMAA
*@param dateRetour la nouvelle date de retour
*/
public void setDateRetour(String dateRetour){
	this.dateRetour = dateRetour;
}
/**
*Change l'etat d'emprunt  ou de disponibilite
*/
public void switchEtat(){
	etatEmp = !etatEmp;
}
/**
*Affiche les caracteristiques d'un  materiel donné
*@return les caracteristiques du materiel
*/
public String toString(){
	if(etatEmp){
	return type+"	"+id+"\nEtat : emprunte le "+dateEmprunt+". Date de retour : "+dateRetour;
	}
	else{return type+"	"+id+"\nEtat : disponible";
}
}

}
