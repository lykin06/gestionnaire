package src;
import java.util.*;
import java.lang.String;
import java.io.*;
/*import java.io.IOException;
import java.util.Scanner;*/

public class Menu{

public static void main(String[] args){

	Emprunteur emprunteur1 = new Emprunteur();
	int rep = 0;
	int j;
	boolean quitter;
	boolean probleme;
	boolean reussi;
	boolean estEmprunteur = false;
	boolean chargement = false;
	String id;
	String nom;
	String prenom;
	String nomF = "";
	String dateEmprunt, dateRetour;
	Atelier atelier1 = new Atelier();
	Materiel mat;
	Scanner sc = new Scanner(System.in);
	Sauvegarde sauv = new Sauvegarde("",atelier1);


	//Quand l'user lance le programme, il peut charger un atelier depuis un fichier
	System.out.println("Charger les données d'un atelier depuis un fichier ? 1 - Oui 2 - Non");
	rep = sc.nextInt();
	if(rep==1){System.out.print("Nom du fichier à lire ? : "); nomF = sc.next();
		   chargement = true;
		   try {
			FileInputStream fich = new FileInputStream(nomF);
			ObjectInputStream ois = new ObjectInputStream(fich);
			Atelier monAtelier = (Atelier) ois.readObject();
			atelier1 = monAtelier;
			chargement = true;
			}
		   catch (java.io.IOException e) {
			e.printStackTrace();
			chargement = false;
			}
		   catch (ClassNotFoundException e) {
			e.printStackTrace(); chargement = false;
			}
	}
	else{rep = 2;}

while(rep!=4){
	System.out.println("Atelier IHM. Que voulez-vous faire ? :\n1 - Service stockage et réparation\n2 - Service emprunt et retour\n3 - Statistiques\n4 - Quitter");
	rep = sc.nextInt();
	switch(rep){
	case 1 :
		//Service stockage et reparation
		System.out.println("Service de stockage et réparation. Que voulez-vous faire ?");
		while(rep!=7){
			System.out.println("1 - Stock\n2 - Ajouter un type de matériels\n3 - Ajouter des matériels\n4 - Matériels en réparation\n5 - Envoyer un matériel en réparation\n6 - Remettre un matériel en stock\n7 - Quitter");
			rep = sc.nextInt();
			switch(rep){
			case 1 : System.out.println(atelier1.getStock()); break;
			
			case 2 : System.out.print("Quel type (0 pour annuler) ? "); nom = sc.next();
				 if(!nom.equals("0")){ 
				      System.out.print("Combien ? ");
				      j = sc.nextInt();
				      reussi = atelier1.getStock().ajouterUnType(nom,j);
				      if(reussi){
			                System.out.println("Ajout effectué");
				      }
				      else{ System.out.println("Type déjà catalogué");}
				 }
				break;
			case 3 : 
				System.out.print("Quel type (0 pour annuler) ? "); nom = sc.next(); 
				if(!nom.equals("0")){
				 System.out.print("Combien ? "); j = sc.nextInt();
				 reussi = atelier1.getStock().ajouterUnNombre(nom,j);
				 if(reussi){System.out.println("Ajout effectué");}
				 else{System.out.println("Type non catalogué");}
				}
				break;
			case 4 :
				System.out.println(atelier1.getListeReparation()); break;
			case 5 :
				System.out.print("Identifiant (0 pour annuler) ? ");
				id = sc.next();
				if(!id.equals("0")){
					reussi = atelier1.reparerMateriel(id);
				 	if(!reussi){System.out.println("Identifiant erroné");}
					else{System.out.println("Matériel envoyé en réparation");}
				}
				break;
			case 6 :
					System.out.print("Identifiant (0 pour annuler) ? ");
					id = sc.next();
					reussi = atelier1.restituerMat(id);
					if(!reussi){ System.out.println("Identifiant erroné");}
					else{System.out.println("Restitution effectuée");}
				break;
			default : rep = 7; break;
			}

		}
	break;




	case 2 :
		//Service emprunt et retour
		System.out.println("Service emprunt et retour. Que voulez-vous faire ?");
		while(rep!=6){
			//tant que l'utilisateur ne desire pas quitter le menu...
			System.out.println("1 - Stock\n2 - Liste des emprunteurs\n3 - Ouvrir un compte emprunteur\n4 - Creer un compte emprunteur\n5 - Retourner un matériel\n6 - Quitter");
			rep = sc.nextInt();
		
		
			switch(rep){
			case 1 : System.out.println(atelier1.getStock()); //On affiche le catalogue
			break;
			case 2 :
				System.out.println(atelier1.getListeEmprunteur());
			break;

			case 3 :
				//Ouverture d un compte emprunteur
				j=0;
				quitter=false;
				emprunteur1 = new Emprunteur();
				while(emprunteur1.getNom().equals("inconnu") && !quitter){
			
					if(j==1){
						//Ligne suivante a mettre sous la portee d une exception. Cmt ??
						System.out.println("Nom non catalogué");
					}
						j=1;
						System.out.println("Identification (tapez 0 pour quitter) : "); 
						System.out.print("Nom : ");
						nom = sc.next();
						if(!nom.equals("0")){
							emprunteur1 = atelier1.getEmprunteur(nom);
						}
						else{quitter=true;}
				}
				if(!quitter){
					System.out.println("Identification réussie");
					estEmprunteur = true;
				}
			
			//La suite = voir plus loin
	
			break;
	
			case 4 :
			//Creation d un compte emprunteur	
				probleme = true;
				quitter = false;
				nom = "";
				emprunteur1 = new Emprunteur();		
				while(probleme && !quitter){
				System.out.println("Creation d'un compte emprunteur (tapez 0 pour quitter) : ");
				System.out.print("Nom : ");
				nom = sc.next();
				System.out.println("Prenom :");
				prenom = sc.next();
					if(!nom.equals("0") && !prenom.equals("0")){
						if(!atelier1.verificationEmprunteur(nom)){				
								atelier1.ajoutEmprunteur(new Emprunteur(nom,prenom));
								probleme = false;
						}
						else{System.out.println("Nom deja attribue");}
					}
					else{quitter = true;}
				} //parenthese du while

				if(!probleme){
					System.out.println("Creation du compte emprunteur reussie");
					System.out.println("Voulez-vous vous connecter sur ce compte ? 1 - Oui 2 - Non");
					rep = sc.nextInt();
					
					if(rep==1){estEmprunteur = true; emprunteur1 = atelier1.getEmprunteur(nom); }
					else{estEmprunteur=false; }
				}
			
			break;

			case 5 :
				System.out.print("Identifiant (0 pour quitter) : ");
				id = sc.next();
				if(!id.equals("0")){
					mat = atelier1.getStock().getMat(id);
					if(mat.getType().equals("inconnu")){System.out.println("Identifiant erroné");}
					else if(!mat.getEtat()){System.out.println("Matériel déjà disponible");}
				  	   else{ String ident=mat.getId();
						  atelier1.retourner(ident);
						  System.out.println("Retour du matériel effectué");
						}
				}
			break;

			default :
				rep = 6;
			}
			
			//Si l utilisateur est desormais un emprunteur...
			while(estEmprunteur){
				System.out.println(emprunteur1.getNom()+" :");
				System.out.println("1 - Stock\n2 - Emprunter\n3 - Compte\n4 - Quitter");
				rep = sc.nextInt();
				switch(rep){
				case 1 :
					System.out.println(atelier1.getStock());
				break;
				case 2 :
					System.out.print("Identifiant (0 pour quitter) : ");
					id = sc.next();
					if(!id.equals("0")){
						mat = atelier1.getStock().getMat(id);
						if(mat.getType().equals("inconnu")){
							System.out.println("Identifiant erroné");
						}
						else if(mat.getEtat()){
							System.out.println("Matériel déjà emprunté");
						}
					   	  else{
							System.out.print("Date d'emprunt (JJMMAA) : ");
							dateEmprunt = sc.next();
							System.out.print("Date de retour (JJMMAA) : ");
							dateRetour = sc.next();
							atelier1.emprunter(emprunteur1,mat,dateEmprunt,dateRetour);
							System.out.println("Emprunt effectué");
							}
					}
				break;
				case 3 :
					System.out.println(emprunteur1);
				break;
				default :
					estEmprunteur=false;
		
				}

			}
		}
	break;


	case 3 :
		while(rep!=0){
		System.out.println("1 - Le plus gros emprunteur\n2 - Le type de matériel le plus emprunté\n3 - Le type de matériel ayant le plus d'exemplaires en réparation\n4 - Quitter");
				rep = sc.nextInt();
					switch(rep){
						case 1 :
							System.out.println(atelier1.plusGrosEmprunteur());
						break;
						case 2 :
							System.out.println(atelier1.typeDeMaterielPlusEmprunte());
						break;
						case 3 :
							System.out.println(atelier1.typeDeMaterielPlusRepare());
						break;
						default :
							rep = 0;
					}
		}
	break;

	default:
		rep = 4;
	}
	

} //accollade du grand while


//Quand l'user quitte le programme, il peut sauvegarder le stock dans un fichier
	System.out.println("Sauvegarder les données de l'atelier courant ? \n1 - Enregistrer\n2 - Enregistrer sous\n3 - Quitter");
	rep = sc.nextInt();
	if(rep==2 || (rep==1 && !chargement)){System.out.print("Nom du fichier à créer ? : "); nom = sc.next();
		        sauv = new Sauvegarde(nom,atelier1);
		        sauv.serialisationStock();
 		       }
	else if(rep==1){ sauv = new Sauvegarde(nomF,atelier1); sauv.serialisationStock();}

	if(rep!=3){	System.out.println("Représentation textuelle ? 1 - Oui 2 - Non"); 
			rep = sc.nextInt();
			if(rep==1){
				System.out.print("Nom du fichier à créer ? : ");
				nom = sc.next();
				sauv = new Sauvegarde(nom,atelier1);
				sauv.ecrire();
				
			}
	}


}


}
