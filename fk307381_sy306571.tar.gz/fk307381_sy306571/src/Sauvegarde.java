package src;
import java.io.*;
import java.util.Scanner;
import java.io.IOException;

public class Sauvegarde{
private String nomFichier;
private Atelier monAtelier;

public Sauvegarde(String fichier,Atelier monAtelier){
	this.nomFichier=fichier;
	this.monAtelier=monAtelier;

}


public void serialisationStock (){

try {
FileOutputStream fichier = new FileOutputStream(nomFichier);
ObjectOutputStream oos = new ObjectOutputStream(fichier);
oos.writeObject(monAtelier);
oos.flush();
oos.close();
}
catch (java.io.IOException e) {
e.printStackTrace();
}

}

 
public Atelier deSerialisationStock(){
 
try {
FileInputStream fich = new FileInputStream(nomFichier);
ObjectInputStream ois = new ObjectInputStream(fich);
Atelier monAtelier1 = (Atelier) ois.readObject();
return monAtelier1;
}
catch (java.io.IOException e) {
e.printStackTrace();
return new Atelier();
}
catch (ClassNotFoundException e) {
e.printStackTrace(); return new Atelier();
}

}

public void ecrire()
		{
			try
			{
				/**
				 * BufferedWriter a besoin d un FileWriter, 
				 * les 2 vont ensemble, on donne comme argument le nom du fichier
				 * true signifie qu on ajoute dans le fichier (append), on ne marque pas par dessus 
				 *				 
				 */
				FileWriter fw = new FileWriter(nomFichier, false);
				
				// le BufferedWriter output auquel on donne comme argument le FileWriter fw cree juste au dessus
				BufferedWriter output = new BufferedWriter(fw);
				
				//on marque dans le fichier ou plutot dans le BufferedWriter qui sert comme un tampon(stream)
				output.write(monAtelier.toString());
				//on peut utiliser plusieurs fois methode write
				
				output.flush();
				//ensuite flush envoie dans le fichier, ne pas oublier cette methode pour le BufferedWriter
				
				output.close();
				//et on le ferme
				System.out.println("fichier créé");
			}
			catch(IOException ioe){
				System.out.print("Erreur : ");
				ioe.printStackTrace();
				}

		}

}

