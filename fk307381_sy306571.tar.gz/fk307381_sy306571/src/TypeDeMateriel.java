package src;
import java.util.ArrayList;
/**
*Cette classe permet de gerer l'ensemble des materiels de méme type dans le stock
**@author Khady FALL et Youssef SALIM
*@version 4.0 (22/11/13)
*/
public class TypeDeMateriel implements java.io.Serializable{ 
/**
*le type de l'ensemble de materiel
*
*/
private String type;

public static  int nombre =100;

private static int nombre2 = 100;
/**
*l'identifiant du type de materiel
*
*/
private String id;
/**
*la liste de materiel du type de materiel
*/
private ArrayList<Materiel> listeDeMat;

/**
*Construit un type de materiel d'indentifiant unique avec un nombre de materiel donne
*@param type le type du materiel
*@nombreDeMat le nombre de materiel de meme type
*
*/

public TypeDeMateriel(String type,int nombreDeMat){
int i;
String id2;
this.type=type;
this.id=type.toUpperCase().substring(0,3)+""+nombre;
nombre++;
listeDeMat = new ArrayList<Materiel>();
	for(i=0;i<nombreDeMat;i++){
		id2 = ""+nombre2;
		nombre2++;
		listeDeMat.add(new Materiel(type,id+id2));
	}

}
/**
*Construit un type de materiel inconnu et d'indentifiant inconnu
*Particulierement util lorsque l'utilisateur rentre une donnée inconnue
*@see TypeDeMateriel(String,int)
*/
public TypeDeMateriel(){
	this.type="inconnu";
	this.id="inconnu";
	this.listeDeMat=null;
}
/**
*Permet de recuperer le type d'un materiel donne
*@return le type du materiel
*/
public String getType(){
return type;
}
/**
*Renseigne le nombre de materiel d'un type
*@return le nombre de materiel
*/
public int nombreDeMateriel(){ return listeDeMat.size();}
/**
*Renseigne l'identifiant du type de materiel
*@return l'identifiant
*/
public String getIdentification(){
return id;
}
/**
*Retourne la liste de materiels d'un type
*@return la liste de materiels d'un type
*/
public ArrayList<Materiel> getListeDeMat(){
	return this.listeDeMat;
}
/**
*Renvoie le materiel  selon son index
*@param  i l'index
*@return un type materiel
*
*/

public Materiel getMateriel(int i){
	return listeDeMat.get(i);
}
/**
*Permet de savoir si un materiel est dans en reparation ou dans le stock courant
*
*@return vrai si le materiel est dans le stock courant,faux sinon
*
*/
public boolean contenuDansLaListe(String id){
	return listeDeMat.contains(new Materiel(type,id));

}
/**
*
*Rajoute un materiel
*@param mat le materiel a ajouter
*
*/
public void ajouterMateriel(Materiel mat){
	listeDeMat.add(mat);
}	
/**
*Permet de savoir si au moins un materiel de ce type peut etre emprunte
*@return vraie si au moins un materiel de ce type peut etre emprunte,faux sinon
*/
public boolean disponibilite(){
	return listeDeMat.contains(new Materiel(type));
}
/**
*Renvoie la liste de materiels de ce type, pouvant etre empruntés
*Utile  lorsqu'un client veut faire un emprunt sur un type de materiels avec un nombre donné
*@return la liste de materiel pouvant etre emprunte
*@see Atelier#emprunter(String ,String ,TypeDeMateriel,String ,String ,nombre)
*/

public ArrayList<Materiel> materielNonEmprunte(){
	ArrayList<Materiel> listeNonEmprunte= new ArrayList<Materiel>();
	for(int i=0;i<listeDeMat.size();i++)
		{if(!listeDeMat.get(i).getEtat())
			{id=listeDeMat.get(i).getId();
				listeNonEmprunte.add(new Materiel(type,id));}
}return listeNonEmprunte;
}
/**
*Permet d'ajouter un nombre de materiel de meme type
*Precondition: le materiel a ajouter  sont de meme type
*@param nb le nombre de materiel de meme type a ajouter
*@see TypeDeMateriel#ajouterMateriel(ArrayList<Materiel>)
*/
public  void ajouterMateriel(int nb){
int i;
String id2;
	for(i=0;i<nb;i++){
		id2 = ""+nombre2;
		nombre2++;
		listeDeMat.add(new Materiel(type,id+id2));
	}
}
/**
*Permet d'ajouter le materiel total d'une liste a la liste courante
*@param la liste dont le materiel est a ajouter 
*@see TypeDeMateriel#ajouterMateriel(nb)
*/
public void ajouterMateriel(ArrayList<Materiel> liste){
	int i;
	for(i=0;i<listeDeMat.size();i++){
		listeDeMat.add(liste.get(i));
	}
}
/**
*Permet de supprimer un materiel de liste de materiels
*Cette methode pourrer etre utile pour la reparation
*@param unMateriel le materiel a enlever
*@see Atelier#reparerMateriel(String ) 
*
*/

public void supprimerMateriel(Materiel unMateriel){
	listeDeMat.remove(unMateriel);
}
/**
*Permet d'afficher les elements de la liste de materiel de meme type
*
*@return les differents materiels de la liste de materiel 
*
*/
private String afficheListeDeMat(){
	
	return listeDeMat.toString();
}
/**
*Donne toutes les informations sur un type de materiel
*
*@return les differents caracteristiques du materiel d'un type donné
*
*/
public String toString()
{
return "\n\tType de materiel   :  "+this.type+"\n\t Nombre de materiels   :  "+nombreDeMateriel()+"\n\t Identification  :  "+this.id+"\nListe de matériels : "+listeDeMat+"\n\t";
}

}
